package com.example.demo.jsonResponse;

public class Email {

    private String pEmail;

    public Email(String pEmail) {
        this.pEmail = pEmail;
    }

    public Email() {
    }

    public String getpEmail() {
        return pEmail;
    }

    public void setpEmail(String pEmail) {
        this.pEmail = pEmail;
    }
}
